﻿#
# Module manifest for module 'Office365-Scoutnet-synk'
#

@{

# Script module or binary module file associated with this manifest.
RootModule = 'Office365-Scoutnet-synk.psm1'

# Version number of this module.
ModuleVersion = '3.1.0'

# Supported PSEditions
# CompatiblePSEditions = @()

# ID used to uniquely identify this module
GUID = '41b4ce61-ef8a-404a-8989-73c1eb3e5e02'

# Author of this module
Author = 'Karl Thorén <karl.thoren@scouterna.se>'

# Company or vendor of this module
CompanyName = 'Scouterna'

# Copyright statement for this module
Copyright = 'c 2019 All rights reserved.'

# Description of the functionality provided by this module
Description = 'Funktioner för att synkronisera Scoutnet med Office 365.'

# Minimum version of the Windows PowerShell engine required by this module
PowerShellVersion = '7.6'

# Name of the Windows PowerShell host required by this module
# PowerShellHostName = ''

# Minimum version of the Windows PowerShell host required by this module
# PowerShellHostVersion = ''

# Minimum version of Microsoft .NET Framework required by this module. This prerequisite is valid for the PowerShell Desktop edition only.
# DotNetFrameworkVersion = ''

# Minimum version of the common language runtime (CLR) required by this module. This prerequisite is valid for the PowerShell Desktop edition only.
# CLRVersion = ''

# Processor architecture (None, X86, Amd64) required by this module
# ProcessorArchitecture = ''

# Modules that must be imported into the global environment prior to importing this module
RequiredModules = @(@{ModuleName='Microsoft.Graph.Authentication';
                        RequiredVersion="2.41.2"; },
                    @{ModuleName='Microsoft.Graph.Users';
                        RequiredVersion="2.41.2"; },
                    @{ModuleName='Microsoft.Graph.Users.Actions';
                        RequiredVersion="2.41.2"; },
                    @{ModuleName='Microsoft.Graph.Groups';
                        RequiredVersion="2.41.2"; },
                    @{ModuleName='Microsoft.Graph.Teams';
                        RequiredVersion="2.41.2"; },
                    @{ModuleName='Microsoft.Graph.Identity.DirectoryManagement';
                        RequiredVersion="2.41.2"; },
                    @{ModuleName='ExchangeOnlineManagement';
                        RequiredVersion="3.10.1"; })

# Assemblies that must be loaded prior to importing this module
# RequiredAssemblies = @()

# Script files (.ps1) that are run in the caller's environment prior to importing this module.
# ScriptsToProcess = @()

# Type files (.ps1xml) to be loaded when importing this module
# TypesToProcess = @()

# Format files (.ps1xml) to be loaded when importing this module
# FormatsToProcess = @()

# Modules to import as nested modules of the module specified in RootModule/ModuleToProcess
# NestedModules = @()

# Functions to export from this module, for best performance, do not use wildcards and do not delete the entry, use an empty array if there are no functions to export.
FunctionsToExport = @(
    'Write-SNSLog',
    'Get-SNSRunSummary',
    'SNSUpdateExchangeDistributionGroups',
    'Send-SNSMandatoryMomentReport',
    'Update-SNMicrosoft365Group',
    'Invoke-SNSUppdateOffice365User',
    'New-SNSConfiguration',
    'Set-SNSConfiguration',
    'Connect-SnSOffice365',
    'Disconnect-SnSOffice365'
)

# Cmdlets to export from this module, for best performance, do not use wildcards and do not delete the entry, use an empty array if there are no cmdlets to export.
CmdletsToExport = ''

# Variables to export from this module
VariablesToExport = @()

# Aliases to export from this module, for best performance, do not use wildcards and do not delete the entry, use an empty array if there are no aliases to export.
AliasesToExport = ''

# DSC resources to export from this module
# DscResourcesToExport = @()

# List of all modules packaged with this module
# ModuleList = @()

# List of all files packaged with this module
# FileList = @()

# Private data to pass to the module specified in RootModule/ModuleToProcess. This may also contain a PSData hashtable with additional module metadata used by PowerShell.
PrivateData = @{

    PSData = @{

        #Prerelease = "rc1"

        # Tags applied to this module. These help with module discovery in online galleries.
        Tags = @('scoutnet',
                 'scouternasetjanster',
                 'scouterna')

        # A URL to the license for this module.
        LicenseUri = 'https://github.com/Scouterna/Office365-Scoutnet-synk/blob/master/LICENSE'

        # A URL to the main website for this project.
        ProjectUri = 'https://github.com/Scouterna/Office365-Scoutnet-synk'

        # A URL to an icon representing this module.
        # IconUri = ''

        # ReleaseNotes of this module
        ReleaseNotes = @'
## 3.1.0
Uppgradering från tidigare versioner: https://github.com/Scouterna/Office365-Scoutnet-synk/wiki/Ny-version

### Nya funktioner
- Ny funktion Update-SNMicrosoft365Group för Microsoft 365-grupper och Teams. Se https://github.com/Scouterna/Office365-Scoutnet-synk/wiki/Manual-Microsoft-365-grupper
- Microsoft.Graph.Teams 2.41.2 är nu ett beroende.
- Listor kan styras av roller och avdelningar i Scoutnet. Se https://github.com/Scouterna/Office365-Scoutnet-synk/wiki/Manual-Distributionsgrupper#source-rollbaserade-distributionsgrupper
- Distributionslistor skapas automatiskt om de saknas. Se https://github.com/Scouterna/Office365-Scoutnet-synk/wiki/Manual-Distributionsgrupper#group_type-skapa-distributionsgrupp-eller-säkerhetsgrupp
- Användare kan läggas i säkerhetsgrupper utifrån Scoutnet. Se https://github.com/Scouterna/Office365-Scoutnet-synk/wiki/Manual-Distributionsgrupper#group_type-skapa-distributionsgrupp-eller-säkerhetsgrupp
- Ämnesprefix för mejl till distributionslistor med add_prefix. Se https://github.com/Scouterna/Office365-Scoutnet-synk/wiki/Manual-Distributionsgrupper#add_prefix-ämnesprefix-för-mejl-till-listan
- Snabbare synk av distributionsgrupper. Oförändrade grupper hoppas över.
- Ny inställning EnableTimingLog för tidsmätning. Se https://github.com/Scouterna/Office365-Scoutnet-synk/wiki/Manual-Distributionsgrupper#tidsmätning
- Ny funktion Get-SNSRunSummary ger en sammanfattning att lägga först i loggmailet. Se https://github.com/Scouterna/Office365-Scoutnet-synk/wiki/Manual-Körningssammanfattning
- Använd gruppens fullständiga e-postadress som nyckel i MailListSettings. Se https://github.com/Scouterna/Office365-Scoutnet-synk/wiki/Manual-Distributionsgrupper
- Använder PowerShells inbyggda autentisering och JSON-hantering mot Scoutnet.
- Bara funktionerna som används i exemplen är publika. Övriga funktioner och variabeln SNSConf är interna.
- Uppdateringsskriptet har hjälp, nya parametrar och lägger till saknade behörigheter.

### Buggfixar
- Rättat TLS-inställningar, rapportutskick och null-varningar.

## 3.0.1

### Nya funktioner
- Flyttade dokumentationen till en separat wiki. Den finns på https://github.com/Scouterna/Office365-Scoutnet-synk/wiki
- Uppdaterade dokumentationen och skripten för att installera en ny version av modulen i Azure Automation, och på en lokal dator. Se dokumentationen på wikin.
- Exemplen i dokumentationen har uppdaterats för att använda de nya funktionerna i modulen.

### Buggfixar
- Rättade buggar i skripten som installerar modulen i Azure Automation.

## 3.0.0

### Nya funktioner
- Uppdaterade och låste Microsoft.Graph modulerna till version 2.41.2. De nyare versionerna fungerar i azure runbooks.
- Uppdaterade ExchangeOnlineManagement till version 3.10.1. Den versionen kräver PowerShell 7.6 i Azure Automation.
- SetupAzure.ps1 uppdaterad så att den kan ta emot parametrar för kontonamn, resursgrupp och plats. Det gör det möjligt att skapa flera olika Azure Automation-konton med olika namn.
- SetupAzure.ps1 installerar version 2.41.2 av Microsoft.Graph modulerna och version 3.10.1 av ExchangeOnlineManagement modulen.
- Lade till support för TLS 1.3 och tog bort äldre versioner.
- Lade till stöd för -WhatIf och -Confirm vid ändringar av mailkontakter och konfiguration.
- Unittester tillagda för att öka kvaliteten och säkerställa att funktioner fungerar som förväntat.
- Stöd för att spara nerladdaade JSON-objekt i en fil för att kunna felsöka problem med Scoutnet API-anrop.
- Stöd för att rapportera obligatoriska moment i Scoutnet via e-post. Funktionen Send-SNSMandatoryMomentReport kan användas för att skicka rapporter om obligatoriska moment till en eller flera e-postadresser.

### Buggfixar
- Rättade hanteringen av maillistor så att konfigurerade Scoutnet-listor väljs utifrån scoutnet_list_id.
- Förhindrade att samma e-postadress läggs till flera gånger i OtherMails när användarkontot uppdateras.
- Ändrade JSON-konverteringen så att varje objekt som skickas via pipeline konverteras separat.
- Justerade utmatningen av samlingsobjekt så att de returneras utan enumerering vid anrop till Write-Output -NoEnumerate.
- Löste linting problem med att använda Write-Output utan -NoEnumerate i en pipeline. Alla lintvarningar är nu lösta.

'@

    } # End of PSData hashtable

} # End of PrivateData hashtable

# HelpInfo URI of this module
# HelpInfoURI = ''

# Default prefix for commands exported from this module. Override the default prefix using Import-Module -Prefix.
# DefaultCommandPrefix = ''

}
