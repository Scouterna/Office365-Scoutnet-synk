﻿function Get-SNSMaillistInfo
{
    <#
    .SYNOPSIS
        Fetches the maillist info from scoutnet and creates a hashtable with the configured lists and their members.

    .DESCRIPTION
        Scoutnet API api/group/customlists returns a JSON with maillist info.
        This function fetches the customlists and creates a hashtable with the configured lists and their member ids.
        This hashtable can be used to generate maillists.

        The function supports that one rule is named 'ledare'. This is to be able to handle them separate.

    .INPUTS
        None. You cannot pipe objects to Get-SNSMaillistInfo.

    .OUTPUTS
        Two parts is returned. The first part is the hashtable. The second part is a hashcode that can be used to check if scoutnet is updated.

    .PARAMETER CredentialCustomlists
        Credentials for api/group/customlists

    .PARAMETER UriApiCustomList
        Url for the API. Defaults to https://www.scoutnet.se/api/group/customlists

    .PARAMETER MaillistsIds
        Mail-list settings to process. Each setting must include scoutnet_list_id and may include statisk_lista.

    .LINK
        https://www.scoutnet.se

    .EXAMPLE
        Get-SNSMaillistInfo -CredentialCustomlists $CredentialCustomLists -Uri "https://www.scoutnet.se/api/group/customlists"
    #>

    [OutputType([System.Collections.Hashtable], [string])]
    param (
        [Parameter(Mandatory=$True, HelpMessage="Credentials for api/group/customlists")]
        [ValidateNotNull()]
        [Alias("Credential")]
        [pscredential]$CredentialCustomlists,

        [Parameter(Mandatory=$False, HelpMessage="Url for api/group/customlists.")]
        [ValidateNotNull()]
        [Alias("Uri")]
        [string]$UriApiCustomList = "https://www.scoutnet.se/api/group/customlists",

        [Parameter(Mandatory=$True, HelpMessage="Maillists to process. A hash-table there the key kan be used to find the list in office365, and the value is the Scoutnet list Id.")]
        [ValidateNotNull()]
        $MaillistsIds
        )

    # Fetch exixting custom lists.
    $CustomLists = @{}

    Write-SNSLog "Fetch the current maillists from Scoutnet"
    $CustomListInfo = Get-SNSApiGroupCustomlist -Credential $CredentialCustomlists -Uri $UriApiCustomList

    # For each list fetch the user id of the members.
    foreach ($key in $CustomListInfo.Keys)
    {
        $matchingMaillists = @($MaillistsIds | Where-Object { $_.scoutnet_list_id -eq $key })
        if ($matchingMaillists.Count -gt 0)
        {
            $ledare = @()
            $scouter = @()

            Write-SNSLog ("Fetching data for maillist {0}" -f ($CustomListInfo[$key].title))
            $mailListSettings = $matchingMaillists[0]

            if ($mailListSettings.statisk_lista)
            {
                # Static list. Fetch users from the list not the rules.
                $ledareData = Get-SNSApiGroupCustomlist -Credential $CredentialCustomlists -Uri $UriApiCustomList -listid $key
                $ledare += @($ledareData.data.keys).Where({ $null -ne $_ })
            }
            else
            {
                # Fetch rule information.
                foreach ($rule in $CustomListInfo[$key].rules.Keys)
                {
                    if ($CustomListInfo[$key].rules[$rule].title -like "*ledare*")
                    {
                        # Fetch the list marked "ledare"
                        $ledareData = Get-SNSApiGroupCustomlist -Credential $CredentialCustomlists -Uri $UriApiCustomList -listid $key -ruleid $CustomListInfo[$key].rules[$rule].id
                        $ledare += @($ledareData.data.keys).Where({ $null -ne $_ })
                    }
                    else
                    {
                        # Fetch the other lists
                        $scouterData = Get-SNSApiGroupCustomlist -Credential $CredentialCustomlists -Uri $UriApiCustomList -listid $key -ruleid $CustomListInfo[$key].rules[$rule].id
                        $scouter += @($scouterData.data.keys).Where({ $null -ne $_ })
                    }
                }
            }
            # Create hashtable with all lists and all users.
            $CustomListData = @{}
            $CustomListData.Add("title",   $CustomListInfo[$key].title)
            $CustomListData.Add("ledare",  $ledare)
            $CustomListData.Add("scouter", $scouter)
            $CustomLists.Add($key, $CustomListData)
        }
    }
    Write-SNSLog "Done"

    return $CustomLists, (Get-SNSStableHash -InputObject $CustomLists)
}