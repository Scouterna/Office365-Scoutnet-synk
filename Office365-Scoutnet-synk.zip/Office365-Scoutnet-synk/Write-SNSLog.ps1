﻿function Write-SNSLog
{
<#
.Synopsis
   Write-SNSLog writes a message to a specified log file with the current time stamp.

.DESCRIPTION
   The Write-SNSLog function is designed to add logging capability to other scripts.
   In addition to writing errors, warnings and verbose messages, the function
   writes to a log file for later debugging.
   The log file path is taken from the LogFilePath setting in the configuration.
   If it is empty, no log file is written.

.PARAMETER Message
   Message is the content that you wish to add to the log file.

.PARAMETER Level
   Specify the criticality of the log information being written to the log (i.e. Error, Warning, Informational)
#>
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [ValidateNotNullOrEmpty()]
        [Alias("LogContent")]
        [string]$Message,

        [Parameter(Mandatory=$false)]
        [ValidateSet("Error","Warn","Info")]
        [string]$Level="Info"
    )

    Process
    {
        if (-not [String]::IsNullOrWhiteSpace($script:SNSConf.LogFilePath))
        {
            # If attempting to write to a log file in a folder/path that doesn't exist create the file including the path.
            if (!(Test-Path $script:SNSConf.LogFilePath))
            {
                Write-Verbose "Creating $($script:SNSConf.LogFilePath)."
                New-Item $script:SNSConf.LogFilePath -Force -ItemType File > $null
            }
        }
        else
        {
            Write-Warning "Log file path is empty. No log file will be created."
        }

        # Format Date for our Log File
        $FormattedDate = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

        # Write message to error, warning, or verbose pipeline and specify $LevelText
        switch ($Level) {
            'Error' {
                Write-Error $Message
                $LevelText = 'ERROR:'
                }
            'Warn' {
                Write-Warning $Message
                $LevelText = 'WARNING:'
                }
            'Info' {
                Write-Verbose $Message
                $LevelText = 'INFO:'
                }
            }

        if (-not [String]::IsNullOrWhiteSpace($script:SNSConf.LogFilePath))
        {
            # Write log entry to $script:LogPath
            "$FormattedDate $LevelText $Message" | Out-File -FilePath $script:SNSConf.LogFilePath -Append -Encoding UTF8
        }
    }
}
