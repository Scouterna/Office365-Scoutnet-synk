﻿class SNSConfiguration
{
    [string]$LogFilePath='scoutnetSync.log'
    [string]$JsonFileDirectory='ScoutnetJson'
    [bool]$SaveJsonFiles=$false
    [bool]$EnableTimingLog=$false
    [string]$SyncGroupName='scoutnet'
    [string]$SyncGroupDescription="Säkerhetsgrupp som används vid synkronisering med Scoutnet. Användare i gruppen avaktiveras om de inte är kvar i Scoutnet."
    [string]$SyncGroupDisabledUsersName='scoutnetDisabledUsers'
    [string]$SyncGroupDisabledUsersDescription="Säkerhetsgrupp som används vid synkronisering med Scoutnet. Användare i gruppen är avaktiverade och finns inte längre med i Scoutnet."
    [string]$AllUsersGroupName=""
    hidden [System.Collections.Hashtable]$LicenseAssignment
    [string]$PreferredLanguage="sv-SE"
    [string]$UsageLocation="SE"
    [string]$WaitMailboxCreationMaxTime="1200"
    [string]$WaitMailboxCreationPollTime="30"
    [string]$SignatureText=""
    [string]$SignatureHtml=""
    [string]$NewUserEmailSubject=""
    [string]$NewUserEmailText=""
    [string]$NewUserEmailContentType="Text"
    [string]$NewUserInfoEmailSubject=""
    [string]$NewUserInfoEmailText=""
    [string]$NewUserInfoEmailContentType="Text"
    [string]$EmailFromAddress = ""
    [string[]]$MandatoryMomentReportRecipients = @()
    [string]$MandatoryMomentReportFrequency = 'Monthly'
    [int]$MandatoryMomentMinimumAge = 15
    [int]$MandatoryMomentValidityYears = 3
    [string]$MandatoryMomentCourseDescription = 'Lista över medlemmar som behöver göra om kursen Trygga möten'
    [string]$MandatoryMomentPoliceCheckDescription = 'Lista över medlemmar som behöver förnya registerutdraget'
    [string[]]$MandatoryMomentExcludedRoles = @()
    [string]$UserSyncMailListId
    [pscredential]$CredentialCustomlists
    [pscredential]$CredentialMemberlist
    [System.Collections.Hashtable]$MailListSettings
    [System.Collections.Hashtable]$Microsoft365GroupSettings
    [string]$DomainName
    [string]$DisabledAccountsAutoReplyText
    [System.Collections.Hashtable]$ApiGroupMemberlistCache
    hidden [String]$commandNames
    hidden [String[]]$RequiredScopes = @("Directory.AccessAsUser.All",
    "Directory.ReadWrite.All",
    "Directory.Read.All",
    "GroupMember.Read.All",
    "GroupMember.ReadWrite.All",
    "Group.ReadWrite.All",
    "Group.Read.All",
    "Team.Create",
    "User.ReadWrite.All",
    "User.Read.All",
    "Mail.Send",
    "Mail.Send.Shared"
    )
}

function New-SNSConfiguration
{
    <#
    .SYNOPSIS
        Creates a new configuration.

    .DESCRIPTION
        Creates a configuration object with the settings for the synchronization and caches it in the module.
        Parameters that are left out keep their default values.

        Settings can be given as parameters, or changed afterwards on the returned object.
        Pass the configuration to Connect-SnSOffice365 and the synchronization functions.

    .EXAMPLE
        $conf = New-SNSConfiguration -LicenseAssignment $licenseAssignment -UserSyncMailListId '1234'
        $conf.DomainName = 'example.se'
        $conf.EnableTimingLog = $true

        Creates a configuration and changes some settings on the returned object.

    .INPUTS
        None. You cannot pipe objects to New-SNSConfiguration.

    .OUTPUTS
        The created configuration

    .PARAMETER CredentialMemberlist
        Credentials for api/group/memberlist

    .PARAMETER CredentialCustomlists
        Credentials for api/group/customlists

    .PARAMETER MailListSettings
        Maillists to process for maillist syncronisation. A hashtable with maillist info.

    .PARAMETER Microsoft365GroupSettings
        Rules for Microsoft 365 groups synchronized from Scoutnet.

    .PARAMETER DomainName
        Domain name for office365 mail addresses.

    .PARAMETER LicenseAssignment
        License assignment data to use when creating a new account.

    .PARAMETER UserSyncMailListId
        List Id to use when syncronising user accounts. If it is empty (default value) then all members with a role will be given an account.

    .PARAMETER LogFilePath
        Logfile name and path. Used to override the default value.

    .PARAMETER JsonFileDirectory
        Directory for downloaded Scoutnet API JSON files.

    .PARAMETER SaveJsonFiles
        Save downloaded Scoutnet API JSON files.

    .PARAMETER EnableTimingLog
        Log elapsed time for the phases and contact commands of the distribution group synchronization. Default is off.

    .PARAMETER AllUsersGroupName
        Name of distribution group to add all new accounts to. The distribution group must exist.

    .PARAMETER SignatureText
        Outlook online signature for new users. Text version.

    .PARAMETER SignatureHtml
        Outlook online signature for new users. Html version.

    .PARAMETER NewUserEmailSubject
        Subject for the mail to the user about the new account. Is sent to the member Scoutnet primary e-mail address.

    .PARAMETER NewUserEmailText
        Body for the mail to the user about the new account. Is sent to the member Scoutnet primary e-mail address.

    .PARAMETER NewUserEmailContentType
        Content type for the email, supported types is HTML and Text. Default is Text.

    .PARAMETER NewUserInfoEmailSubject
        Subject for the mail to the users new e-mail address. Can be used to inform the user about the system.

    .PARAMETER NewUserInfoEmailText
        Body for the mail to the users new e-mail address. Can be used to inform the user about the system.

    .PARAMETER NewUserInfoEmailContentType
        Content type for the email, supported types is HTML and Text. Default is Text.

    .PARAMETER EmailFromAddress
        From address for all mails. The authenticaion account must be able to send as this address.

    .PARAMETER DisabledAccountsAutoReplyText
        Autoreply message for disabled accounts.
        If set this text is set as autoreply message for disabled accounts. Html is supported.
    #>
    [Diagnostics.CodeAnalysis.SuppressMessageAttribute(
        'PSUseShouldProcessForStateChangingFunctions',
        '',
        Justification = 'Funktionen skapar och returnerar endast ett konfigurationsobjekt; den ändrar inte systemtillstånd.'
    )]
    [OutputType([SNSConfiguration])]
    param
    (
        [Parameter(HelpMessage="Credentials for api/group/memberlist.")]
        [pscredential]$CredentialMemberlist,

        [Parameter(HelpMessage="Credentials for api/group/customlist.")]
        [pscredential]$CredentialCustomlists,

        [Parameter(HelpMessage="Maillists to process.")]
        $MailListSettings,

        [Parameter(HelpMessage="Rules for Microsoft 365 groups.")]
        [System.Collections.Hashtable]$Microsoft365GroupSettings,

        [Parameter(HelpMessage="Domain name for office365 mail addresses.")]
        [string]$DomainName,

        [Parameter(Mandatory=$true, HelpMessage="License data.")]
        [ValidateNotNull()]
        $LicenseAssignment,

        [Parameter(HelpMessage="List Id to use when syncronising user accounts.")]
        $UserSyncMailListId,

        [Parameter(HelpMessage="Logfile name and path.")]
        [string]$LogFilePath,

        [Parameter(HelpMessage="Directory for downloaded Scoutnet API JSON files.")]
        [string]$JsonFileDirectory,

        [Parameter(HelpMessage="Save downloaded Scoutnet API JSON files.")]
        [bool]$SaveJsonFiles,

        [Parameter(HelpMessage="Log elapsed time for the distribution group synchronization.")]
        [bool]$EnableTimingLog,

        [Parameter(HelpMessage="Name of distribution group to add all new accounts to.")]
        [string]$AllUsersGroupName,

        [Parameter(HelpMessage="Outlook online signature for new users. Text version.")]
        [string]$SignatureText,

        [Parameter(HelpMessage="Outlook online signature for new users. Html version.")]
        [string]$SignatureHtml,

        [Parameter(HelpMessage="Subject for the mail to the user about the new account.")]
        [string]$NewUserEmailSubject,

        [Parameter(HelpMessage="Body for the mail to the user about the new account.")]
        [string]$NewUserEmailText,

        [Parameter(HelpMessage="Content type for the email, supported types is Html and Text. Default is Text.")]
        [string]$NewUserEmailContentType,

        [Parameter(HelpMessage="Subject for the mail to the users new e-mail address.")]
        [string]$NewUserInfoEmailSubject,

        [Parameter(HelpMessage="Body for the mail to the users new e-mail address.")]
        [string]$NewUserInfoEmailText,

        [Parameter(HelpMessage="Content type for the email, supported types is Html and Text. Default is Text.")]
        [string]$NewUserInfoEmailContentType,

        [Parameter(HelpMessage="Autoreply message for disabled accounts.")]
        [string]$DisabledAccountsAutoReplyText
    )

    $conf = [SNSConfiguration]::new()

    if ($MailListSettings)
    {
        $conf.MailListSettings = $MailListSettings
    }

    if ($PSBoundParameters.ContainsKey('Microsoft365GroupSettings'))
    {
        $conf.Microsoft365GroupSettings = $Microsoft365GroupSettings
    }

    if ($NewUserInfoEmailText)
    {
        $conf.NewUserInfoEmailText = $NewUserInfoEmailText
    }

    if ($NewUserInfoEmailContentType)
    {
        $conf.NewUserInfoEmailContentType = $NewUserInfoEmailContentType
    }

    if ($NewUserInfoEmailSubject)
    {
        $conf.NewUserInfoEmailSubject = $NewUserInfoEmailSubject
    }

    if ($NewUserEmailText)
    {
        $conf.NewUserEmailText = $NewUserEmailText
    }

    if ($NewUserEmailContentType)
    {
        $conf.NewUserEmailContentType = $NewUserEmailContentType
    }

    if ($NewUserEmailSubject)
    {
        $conf.NewUserEmailSubject = $NewUserEmailSubject
    }

    if ($SignatureHtml)
    {
        $conf.SignatureHtml = $SignatureHtml
    }

    if ($SignatureText)
    {
        $conf.SignatureText = $SignatureText
    }

    if ($AllUsersGroupName)
    {
        $conf.AllUsersGroupName = $AllUsersGroupName
    }

    if ($LogFilePath)
    {
        $conf.LogFilePath = $LogFilePath
    }

    if ($PSBoundParameters.ContainsKey('JsonFileDirectory'))
    {
        $conf.JsonFileDirectory = $JsonFileDirectory
    }

    if ($PSBoundParameters.ContainsKey('SaveJsonFiles'))
    {
        $conf.SaveJsonFiles = $SaveJsonFiles
    }

    if ($PSBoundParameters.ContainsKey('EnableTimingLog'))
    {
        $conf.EnableTimingLog = $EnableTimingLog
    }

    if ($CredentialMemberlist)
    {
        $conf.CredentialMemberlist = $CredentialMemberlist
    }

    if ($CredentialCustomlists)
    {
        $conf.CredentialCustomlists = $CredentialCustomlists
    }

    if ($DomainName)
    {
        $conf.DomainName = $DomainName
    }

    if ($UserSyncMailListId)
    {
        $conf.UserSyncMailListId = $UserSyncMailListId
    }

    if ($DisabledAccountsAutoReplyText)
    {
        $conf.DisabledAccountsAutoReplyText = $DisabledAccountsAutoReplyText
    }

    if ($LicenseAssignment)
    {
        $conf.LicenseAssignment = $LicenseAssignment
    }

    # Exchange online commands to use.
    $conf.commandNames = "Get-EXOMailbox,Get-EXORecipient,"
    $conf.commandNames += "Get-DistributionGroupMember,Get-DistributionGroup,"
    $conf.commandNames += "Update-DistributionGroupMember,New-MailContact,"
    $conf.commandNames += "Set-Contact,Set-MailContact,Remove-MailContact,"
    $conf.commandNames += "Set-MailContact,Set-Mailbox,Remove-DistributionGroupMember,"
    $conf.commandNames += "Add-DistributionGroupMember,Get-DistributionGroupMember,"
    $conf.commandNames += "Get-DistributionGroup,Set-MailboxMessageConfiguration,"
    $conf.commandNames += "Set-MailboxAutoReplyConfiguration,"
    $conf.commandNames += "Get-Contact,"
    $conf.commandNames += "Get-TransportRule,New-TransportRule,Set-TransportRule,"
    $conf.commandNames += "New-DistributionGroup,Set-DistributionGroup"

    return $conf
}

function Get-SNSConfiguration
{
    <#
    .SYNOPSIS
        Fetch current configuration.

    .INPUTS
        None. You cannot pipe objects to Get-SNSConfiguration.

    .OUTPUTS
        SNSConfiguration. The current configuration cached in the module.
    #>
    [OutputType([SNSConfiguration])]
    param
    (
    )

    return $script:SNSConf
}

function Set-SNSConfiguration
{
    <#
    .SYNOPSIS
        Sets the current configuration.

    .DESCRIPTION
        Replaces the configuration cached in the module with the given configuration.
        Supports -WhatIf and -Confirm.

    .INPUTS
        None. You cannot pipe objects to Set-SNSConfiguration.

    .OUTPUTS
        None.

    .PARAMETER Configuration
        The configuration to use, created with New-SNSConfiguration.

    .EXAMPLE
        Set-SNSConfiguration -Configuration $conf

        Makes $conf the current configuration.
    #>
    [CmdletBinding(SupportsShouldProcess=$true)]
    param
    (
        [Parameter(Mandatory=$True, HelpMessage="The new configuration.")]
        $Configuration
    )

    if ($PSCmdlet.ShouldProcess("SNSConfiguration", "Set current configuration"))
    {
        $script:SNSConf = $Configuration
    }
}
